﻿using Hyperion.Infrastructure.Database;
using System;
using System.Collections.Generic;
using System.Text;

namespace Authorizer.Domain.Aggregates.Account.Repository
{
    public interface IAccountRepository : IRepository<Account>
    {

    }
}
