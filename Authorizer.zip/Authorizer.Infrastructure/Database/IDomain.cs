﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Authorizer.Infrastructure.Database
{
    public interface IDomain<T> where T : class
    {

    }
}
