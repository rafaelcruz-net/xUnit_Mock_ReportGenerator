﻿using Authorizer.Domain.Aggregates.Account;
using Authorizer.Domain.Aggregates.Account.Repository;
using Authorizer.Infrastructure.Exception;
using Authorizer.Infrastructure.Specification;
using Authorizer.Service.Account;
using Authorizer.Service.Account.Dto;
using FluentAssertions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Authorizer.Tests
{
    public class AccountTests
    {

        private Mock<IAccountRepository> _repository;
        private IAccountService accountService;



        [Fact]
        public async Task Should_Setup_Account_Correctly()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).Verifiable();
            _repository.Setup(x => x.Save(It.IsAny<Account>()));
            _repository.Setup(x => x.SaveChanges());

            var expected = await accountService.CreateAccount(new Service.Account.Dto.AccountDto()
            {
                ActiveCard = true,
                Limit = 100
            });

            expected.Should().NotBeNull();
            expected.ActiveCard.Should().BeTrue();
            expected.Limit.Should().Be(100);

            _repository.VerifyAll();

        }

        [Fact]
        public async Task Should_Setup_Account_Result_In_Account_Already_Initialized()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            await Assert.ThrowsAsync<BusinessException>(async () =>
            {
                await accountService.CreateAccount(new Service.Account.Dto.AccountDto()
                {
                    ActiveCard = true,
                    Limit = 100
                });
            });
        }

        [Fact]
        public async Task Should_Accept_Transaction()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            TransactionDto transaction = new TransactionDto()
            {
                Amount = 50,
                Merchant = "Nubank",
                Time = DateTime.Now
            };

            _repository.Setup(x => x.Save(It.IsAny<Account>()));
            _repository.Setup(x => x.SaveChanges());

            var expected = await accountService.CreateTransaction(transaction);

            expected.Should().NotBeNull();
            expected.Limit.Should().Be(50);
            expected.ActiveCard.Should().BeTrue();
            account.Transactions.Should().HaveCount(1);

            _repository.VerifyAll();
        }

        [Fact]
        public async Task Should_Transaction_Result_In_Insufficent_Limit()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            TransactionDto transaction = new TransactionDto()
            {
                Amount = 150,
                Merchant = "Nubank",
                Time = DateTime.Now
            };

            var bex = await Assert.ThrowsAsync<BusinessException>(async () =>
            {
                await accountService.CreateTransaction(transaction);
            });

            bex.Errors.First().ErrorMessage.Should().Be("insufficient-limit");

        }

        [Fact]
        public async Task Should_Transaction_Result_Card_Not_Active()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = false,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            TransactionDto transaction = new TransactionDto()
            {
                Amount = 80,
                Merchant = "Nubank",
                Time = DateTime.Now
            };

            var bex = await Assert.ThrowsAsync<BusinessException>(async () =>
            {
                await accountService.CreateTransaction(transaction);
            });

            bex.Errors.First().ErrorMessage.Should().Be("account-not-active");
        }

        [Fact]
        public async Task Should_Transaction_Result_High_Frequency_Small_Interval()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1,
                Transactions = new List<Transaction>()
                {
                    new Transaction()
                    {
                        Amount = new Domain.Aggregates.Account.ValueObjects.Amount(100),
                        Merchant = new Domain.Aggregates.Account.ValueObjects.Merchant("Nubank"),
                        Time = DateTime.Now.AddMinutes(-1)
                    },
                    new Transaction()
                    {
                        Amount = new Domain.Aggregates.Account.ValueObjects.Amount(80),
                        Merchant = new Domain.Aggregates.Account.ValueObjects.Merchant("Burger King"),
                        Time = DateTime.Now.AddSeconds(-30)
                    },
                    new Transaction()
                    {
                        Amount = new Domain.Aggregates.Account.ValueObjects.Amount(60),
                        Merchant = new Domain.Aggregates.Account.ValueObjects.Merchant("Mc Donalds"),
                        Time = DateTime.Now
                    },
                }
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            TransactionDto transaction = new TransactionDto()
            {
                Amount = 60,
                Merchant = "Nubank",
                Time = DateTime.Now
            };

            var bex = await Assert.ThrowsAsync<BusinessException>(async () =>
            {
                await accountService.CreateTransaction(transaction);
            });

            bex.Errors.First().ErrorMessage.Should().Be("high-frequency-small-interval");
        }


        [Fact]
        public async Task Should_Transaction_Result_Double_Transaction()
        {
            _repository = new Mock<IAccountRepository>();
            accountService = new AccountService(_repository.Object);

            var account = new Account()
            {
                ActiveCard = true,
                AvailableLimit = new Domain.Aggregates.Account.ValueObjects.Limit(100),
                AccountId = 1,
                Transactions = new List<Transaction>()
                {
                    new Transaction()
                    {
                        Amount = new Domain.Aggregates.Account.ValueObjects.Amount(100),
                        Merchant = new Domain.Aggregates.Account.ValueObjects.Merchant("Nubank"),
                        Time = DateTime.Now.AddMinutes(-1)
                    },
                    new Transaction()
                    {
                        Amount = new Domain.Aggregates.Account.ValueObjects.Amount(80),
                        Merchant = new Domain.Aggregates.Account.ValueObjects.Merchant("Burger King"),
                        Time = DateTime.Now.AddSeconds(-30)
                    }
                }
            };

            _repository.Setup(x => x.GetOneByCriteria(It.IsAny<ISpecification<Account>>())).ReturnsAsync(account).Verifiable();

            TransactionDto transaction = new TransactionDto()
            {
                Amount = 100,
                Merchant = "Nubank",
                Time = DateTime.Now
            };

            var bex = await Assert.ThrowsAsync<BusinessException>(async () =>
            {
                await accountService.CreateTransaction(transaction);
            });

            bex.Errors.First().ErrorMessage.Should().Be("doubled-transaction");
        }


    }
}
